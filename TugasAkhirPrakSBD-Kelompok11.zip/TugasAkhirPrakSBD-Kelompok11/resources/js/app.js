import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

import 'flowbite';

Alpine.start();
